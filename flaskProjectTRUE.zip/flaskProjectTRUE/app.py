from flask import Flask, render_template, request, redirect, url_for, send_file
from docx import Document
import re
import os
from io import BytesIO
import docx2txt
from odf import text, teletype
from odf.opendocument import load

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']

    if file and file.filename.lower().endswith(('.txt', '.doc', '.docx', '.pdf', '.rtf', '.odt')):
        if file.content_type == 'text/plain':
            content = file.read().decode('utf-8')
            updated_content = remove_personal_data(content)
        elif file.filename.lower().endswith(('.docx', '.odt')):
            updated_content = remove_personal_data_from_doc(file)
        else:
            return "Przesłano nieobsługiwany plik."

        updated_filename = "Updated_" + file.filename

        # Utwórz folder UploadedFiles, jeśli nie istnieje
        upload_folder = os.path.join(app.root_path, 'UploadedFiles')
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        updated_filepath = os.path.join(upload_folder, updated_filename)

        # Zapisz przetworzony plik
        with open(updated_filepath, 'wb') as updated_file:
            if isinstance(updated_content, str):  # Jeśli zawartość jest typu str, zakoduj ją na bajty
                updated_file.write(updated_content.encode('utf-8'))
            else:  # W przeciwnym razie, zapisz dane bez ponownego kodowania
                updated_file.write(updated_content)

        return redirect(url_for('download', filename=updated_filename))

    return "Przesłano nieobsługiwany plik."



@app.route('/download/<filename>')
def download(filename):
    upload_folder = os.path.join(app.root_path, 'UploadedFiles')
    file_path = os.path.join(upload_folder, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return "Plik nie istnieje."


def remove_personal_data(content):
    # Usuń dane osobowe z tekstu
    content = re.sub(r'\b\d{11}\b', '#' * 11, content)  # PESEL
    content = re.sub(r'\b[A-Z]{3}\d{6}\b', '#' * 9, content)  # Numer dowodu osobistego
    content = re.sub(r'(\+\d{2})?\d{3}-\d{3}-\d{3}\b', '#' * 9, content)  # Numer telefonu w formacie XXX-XXX-XXX
    content = re.sub(r'(\+\d{2})?\d{2}\s*\d{3}\s*\d{3}\s*\d{3}\b', '#' * 9, content)  # Numer telefonu w formacie XXX XXX XXX
    content = re.sub(r'(\+\d{2})?\(\d{3}\)\s*\d{3}-\d{3}\b', '#' * 9, content)  # Numer telefonu w formacie (XXX) XXX-XXX
    content = re.sub(r'\b\d{26}\b', '#' * 26, content)  # Numer konta bankowego
    content = re.sub(r'\b(\d{4}-){3}\d{4}\b', '#' * 19, content)  # Numer karty kredytowej
    content = re.sub(r'\b(\d{2}-\d{3})?(\d{3}-\d{2}-\d{2}|\d{3}-\d{3}-\d{3}|\d{9})\b', '#' * 9, content)  # Numer telefonu różne formaty
    content = re.sub(r'\bul\.\s[A-Za-z]+\s\d{1,3}(/(\d{1,3}|\w+))?(\s?,\s?[A-Za-z]+\s\d{2}-\d{3})?\b', '#' * 30, content)  # Adres w formacie ul. Nazwa numer/mieszkanie, Miasto kod-pocztowy
    content = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b', '#' * 15, content)  # Adres email
    content = re.sub(r'\b[A-Za-z]+\s[A-Za-z]+\b', '#' * 15, content)  # Imię i nazwisko

    return content


def remove_personal_data_from_doc(file):
    if file.filename.lower().endswith('.docx'):
        document = Document(file)
        remove_personal_data_from_docx(document)
        updated_file = BytesIO()
        document.save(updated_file)
        return updated_file.getvalue()
    elif file.filename.lower().endswith('.odt'):
        doc = load(file)
        remove_personal_data_from_odt(doc)
        updated_file = BytesIO()
        doc.save(updated_file)
        return updated_file.getvalue()
    else:
        return None



def remove_personal_data_from_docx(document):
    # Anonimizuj tekst w paragrafach
    for paragraph in document.paragraphs:
        paragraph_text = paragraph.text
        updated_text = remove_personal_data(paragraph_text)
        paragraph.clear()  # Wyczyść zawartość paragrafu
        paragraph.add_run(updated_text)  # Dodaj zaktualizowany tekst

    # Anonimizuj tekst w tabelach
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                cell_text = cell.text
                updated_cell_text = remove_personal_data(cell_text)
                cell.clear()  # Wyczyść zawartość komórki
                cell.text = updated_cell_text  # Dodaj zaktualizowany tekst


def remove_personal_data_from_odt(doc):
    for para in doc.getElementsByType(text.P):
        text_content = teletype.extractText(para)
        updated_text_content = remove_personal_data(text_content)
        parent = para.parentNode
        parent.removeChild(para)
        new_para = text.P(text=updated_text_content)
        parent.appendChild(new_para)



if __name__ == '__main__':
    app.run()
